class LLMGuardValidationError(ValueError):
    pass
